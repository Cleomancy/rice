# RICE MY LINUX
like pimp my ride

I use DWM and friends to make my pc look pretty, This is my preconfigured build

PREREQ. xorg-server, xorg-xinit, libxinerama, libxft, feh and unclutter


Feel free to use it.
